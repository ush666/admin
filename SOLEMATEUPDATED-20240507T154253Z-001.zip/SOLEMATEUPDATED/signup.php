<?php
$Name = $_POST['Name'];
$Email = $_POST['Email'];
$Password = $_POST['Password'];

// Database connection
$conn = new mysqli('localhost','root','','solemates');
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}

// Insert data into signup table
$stmt = $conn->prepare("INSERT INTO signup (SignedUpName, SignedUpEmail, SignedUpPassword) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $Name, $Email, $Password);
$stmt->execute();
$stmt->close();

// Insert data into user table
$stmt = $conn->prepare("INSERT INTO user (UserEmail, UserPassword) VALUES (?, ?)");
$stmt->bind_param("ss",$Email, $Password);
$stmt->execute();
$stmt->close();

$conn->close();

header("Location: landingpageafterloggedin.html");
exit();
?>
