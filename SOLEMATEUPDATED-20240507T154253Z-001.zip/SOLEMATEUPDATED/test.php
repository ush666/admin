<?php
    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "solemates";

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Get form data
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Prepare a SQL statement to check if the email and password match a user in the database
        $stmt = $conn->prepare("SELECT * FROM user WHERE UserEmail = ? AND UserPassword = ?");
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        // If a matching user was found, redirect to the landing page
        if ($result->num_rows == 1) {
            header('Location: landingpageafterloggedin.html');
            exit;
        } else {
            // If no matching user was found, display an error message
            echo "Invalid email or password";
        }
    }

    // Close the database connection
    $conn->close();
?>
